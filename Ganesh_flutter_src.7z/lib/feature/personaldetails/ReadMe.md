## Personal Details Functionality

personal details page having reactive form with two dropdown's

## workflow forward : new lead submission

## workflow reverse : preview of submitted lead or draft lead

PersonalDataInit event - data's for form . dropdown values for lov dropdown

PersonalDetails Object - which represent the personaldetails page formfields

this will be required to make leadsubmit request

for draft and submitted leads , onInit , PersonalDetails Object will be loaded with leadAPI data

Events

PersonalDetailsInitEvent
