// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cif_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CifResponse _$CifResponseFromJson(Map<String, dynamic> json) => CifResponse(
  lleadtitle: json['lleadtitle'] as String,
  lleadfrstname: json['lleadfrstname'] as String,
  lleadmidname: json['lleadmidname'] as String,
  lleadlastname: json['lleadlastname'] as String,
  lleademailid: json['lleademailid'] as String,
  lleaddob: json['lleaddob'] as String,
  lleadmobno: json['lleadmobno'] as String,
  lleadpanno: json['lleadpanno'] as String,
  lleadadharno: json['lleadadharno'] as String,
  lleadaddress: json['lleadaddress'] as String,
  lleadaddresslane1: json['lleadaddresslane1'] as String,
  lleadaddresslane2: json['lleadaddresslane2'] as String,
  lleadstate: json['lleadstate'] as String,
  lleadcity: json['lleadcity'] as String,
  lleadpinno: json['lleadpinno'] as String,
  lldCbsid: json['lldCbsid'] as String,
  lldGender: json['lldGender'] as String,
  lldFatherName: json['lldFatherName'] as String,
  lldMotherName: json['lldMotherName'] as String,
  lldReligion: json['lldReligion'] as String,
  lldCaste: json['lldCaste'] as String,
  lldMaritialStatus: json['lldMaritialStatus'] as String,
  lleadResidentStatus: json['lleadResidentStatus'] as String,
);

Map<String, dynamic> _$CifResponseToJson(CifResponse instance) =>
    <String, dynamic>{
      'lleadtitle': instance.lleadtitle,
      'lleadfrstname': instance.lleadfrstname,
      'lleadmidname': instance.lleadmidname,
      'lleadlastname': instance.lleadlastname,
      'lleademailid': instance.lleademailid,
      'lleaddob': instance.lleaddob,
      'lleadmobno': instance.lleadmobno,
      'lleadpanno': instance.lleadpanno,
      'lleadadharno': instance.lleadadharno,
      'lleadaddress': instance.lleadaddress,
      'lleadaddresslane1': instance.lleadaddresslane1,
      'lleadaddresslane2': instance.lleadaddresslane2,
      'lleadstate': instance.lleadstate,
      'lleadcity': instance.lleadcity,
      'lleadpinno': instance.lleadpinno,
      'lldCbsid': instance.lldCbsid,
      'lldGender': instance.lldGender,
      'lldFatherName': instance.lldFatherName,
      'lldMotherName': instance.lldMotherName,
      'lldReligion': instance.lldReligion,
      'lldCaste': instance.lldCaste,
      'lldMaritialStatus': instance.lldMaritialStatus,
      'lleadResidentStatus': instance.lleadResidentStatus,
    };
