/* 
@author     : karthick.d 29-05-2025
@desc       : class ProgressEvent that encapsulate Diff Events
 */

part of 'progress_bloc.dart';

class ProgressEvent {}

class ProgressInit extends ProgressEvent {}

class Progressing extends ProgressEvent {}
