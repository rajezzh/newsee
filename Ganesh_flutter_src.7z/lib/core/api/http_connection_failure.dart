import 'package:newsee/core/api/failure.dart';

class HttpConnectionFailure extends Failure {
  HttpConnectionFailure({required super.message});
}
