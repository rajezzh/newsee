import 'package:flutter/material.dart';
import 'package:newsee/AppSamples/ToolBarWidget/view/toolbar_view.dart';

class ToolBarSample extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Toolbar Sample', home: ToolbarView());
  }
}
