// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lov.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Lov _$LovFromJson(Map<String, dynamic> json) => Lov(
  Header: json['Header'] as String,
  optvalue: json['optvalue'] as String,
  optDesc: json['optDesc'] as String,
  optCode: json['optCode'] as String,
);

Map<String, dynamic> _$LovToJson(Lov instance) => <String, dynamic>{
  'Header': instance.Header,
  'optvalue': instance.optvalue,
  'optDesc': instance.optDesc,
  'optCode': instance.optCode,
};
