class ValidationMessages {
  static const String RESTRICTED_CHAR_ERROR =
      'Restricted Special Characters Not Allowed';
}
