class ApiConstants {
  static const String successCode = '000';
  static const String master_key_lov = 'Listofvalues';
  static const String master_key_products = 'ProductMaster';
  static const String master_key_productschema = 'ProductScheme';
  static const String master_key_statecity = 'StateCityMaster';
  static const String api_response_success = 'Success';
  static const String api_response_failure = 'Failed';
}
